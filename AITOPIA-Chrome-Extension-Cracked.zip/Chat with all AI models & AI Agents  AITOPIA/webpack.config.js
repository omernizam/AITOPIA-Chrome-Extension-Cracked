module.exports = {
  entry: ['./dist_partner/service-worker-loader.js'],
  output: {
    filename: 'bundle.js'
  }
};
